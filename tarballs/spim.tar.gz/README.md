# SPIM OS X installer
This repository hosts a homebrew compatible SPIM package for use on OS X Lion.

SPIM itself is distributed under a BSD license. All rights reserved. Copyright (c) 1990-2010, James R. Larus.
