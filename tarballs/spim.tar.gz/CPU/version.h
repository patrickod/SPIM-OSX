#define SPIM_VERSION "Version 9.1.7 of February 12, 2012"
